package enums;

public enum EnumOperations {
	
	None,
	Add,
	Substract,
	Divide,
	Multiply

}
