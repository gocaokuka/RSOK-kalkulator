package interfaces;

public interface IOperations {

	/**
	 * Adds two numbers.
	 * @return result of adding two numbers
	 */
	public double Add();
	/**
	 * 
	 * @return result of substracing two numbers
	 */
	public double Substract();
	
	/**
	 * asdlaskdjas
	 * @return dsadasdsa
	 */
	public double Mulultiply();
	public double Divide();
	public double Execute();
	
}
